from .main import solve
