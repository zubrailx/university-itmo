from .lab import solve
