#include<stdio.h>

int main() {
  printf("pineapple pizza is good! (not really)\n");
  return 0;
}
